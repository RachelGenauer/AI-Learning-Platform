# AI-Learning-Platform
AI Learning Platform – Mini MVP A full-stack mini platform that allows users to select learning topics, send prompts to an AI (like ChatGPT), and receive dynamic lessons. Built with FastAPI &amp; React, including user management, prompt history, and an admin dashboard.
